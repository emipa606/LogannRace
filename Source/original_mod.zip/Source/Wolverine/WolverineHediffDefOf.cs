﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace Wolverine
{
    [DefOf]
    public static class WolverineHediffDefOf
    {
        public static HediffDef WolverineProtoBodypart;
        public static HediffDef WolverineCuredBodypart;
    }
}
